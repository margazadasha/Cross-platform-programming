package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val averageTextView = findViewById<TextView>(R.id.averageTextView)
        val medianTextView = findViewById<TextView>(R.id.medianTextView)
        val calculateButton = findViewById<View>(R.id.calculateButton)

        val numbers = listOf(3, 5, 7, 2, 9, 4, 6, 8, 1, 10, 12, 11)

        calculateButton.setOnClickListener {
            val average = numbers.average()
            val median = numbers.sorted().let {
                if (it.size % 2 == 0) {
                    (it[it.size / 2] + it[it.size / 2 - 1]) / 2.0
                } else {
                    it[it.size / 2].toDouble()
                }
            }

            averageTextView.text = "Середнє арифметичне: $average"
            medianTextView.text = "Медіана: $median"
        }
    }
}
