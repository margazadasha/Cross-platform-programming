package com.example.myapplication

import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Ініціалізація Spinner для вибору дня тижня
        val daySpinner: Spinner = findViewById(R.id.day_spinner)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.days_of_week,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        daySpinner.adapter = adapter

        // Ініціалізація TextView для кожного заняття
        val firstLesson: TextView = findViewById(R.id.first_lesson)
        val secondLesson: TextView = findViewById(R.id.second_lesson)
        val thirdLesson: TextView = findViewById(R.id.third_lesson)

        // Встановлення слухача для вибору дня тижня
        daySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                when (position) {
                    0 -> { // Понеділок
                        firstLesson.text = getString(R.string.monday_first_lesson)
                        secondLesson.text = getString(R.string.monday_second_lesson)
                        thirdLesson.text = getString(R.string.monday_third_lesson)
                    }
                    1 -> { // Вівторок
                        firstLesson.text = getString(R.string.tuesday_first_lesson)
                        secondLesson.text = getString(R.string.tuesday_second_lesson)
                        thirdLesson.text = getString(R.string.tuesday_third_lesson)
                    }
                    // Додати логіку для інших днів
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Нічого не робити
            }
        }
    }
}